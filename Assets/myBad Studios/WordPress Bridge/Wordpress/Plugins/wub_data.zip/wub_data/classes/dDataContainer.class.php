<?php

class dDataContainer {
	var $gid = 0,
		$cat = "",
		$fields,
		$tableindex,
		$tablevalue,
		$pro = false;

	public function __construct($gid, $cat)
	{
		$this->gid	= $gid;
		$this->cat	= $cat;
		$this->pro   = Posted('WUDPRO') != '';
	   	$this->tableindex = wub_prefix . "dataindex";
	   	$this->tablevalue = wub_prefix . "datavalues";
	}

	public function AddField($name, $val)
	{
		$this->fields[$name] = $val;
	}
	
	public function ToCML()
	{
		if ($this->pro) {
			if (trim($this->cat) == '')
				$this->cat = 'Global';
			$result = SendNode($this->cat);
		}
		else
			$result = "<_CATEGORY_>category=$this->cat\n";
		foreach($this->fields as $key => $val)
			$result .= SendField($key, $val);
		if ($this->pro)
			$result.= SendNode("/{$this->cat}");
		return $result;
	}
	
	function FetchOrCreateID($uid)
	{
		global $wpdb;

		$query = "SELECT id FROM $this->tableindex WHERE uid={$uid} AND gid={$this->gid} AND cat='{$this->cat}';";
		$id = $wpdb->get_var($query);
		if ($id)
			return $id;
		
		$wpdb->insert($this->tableindex, array('uid' => $uid, 'gid' => $this->gid, 'cat' => $this->cat), array('%d','%d','%s',));
		return $wpdb->insert_id;
	}
	
	public function commit_fields($uid)
	{
		global $wpdb;
		if (null == $this->fields)
			return;

		$id = $this->FetchOrCreateID($uid);
		foreach($this->fields as $key => $value)
		{
			$query  = "INSERT INTO $this->tablevalue (id, fid, fval) VALUES ('$id', '$key', '$value') "
					. " ON DUPLICATE KEY UPDATE fval = '$value'";

            $wpdb->query($query);
		}
	}
}
