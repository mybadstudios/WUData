<?php
/*
	dData function list
	===================
	public function ReturnResults($print_gid = false)

	public function fetch_field($fid)
	public function fetch_cat($cat = "")
	public function fetch_game($gid = -1)
	public function fetch_global_info()
	public function fetch_all_user_data()	
*/

class dData {
	var $uid = 0,
		$gid = 0,
		$cat = "",
		$table,
		$tableindex,
		$tablevalue;

	var $data = null;

	public function __construct($gid, $uid, $cat="")
	{
		$this->uid	 = $uid;
		$this->gid	 = $gid;
		$this->cat	 = $cat;
	   	$this->table = wub_prefix . "data";
	   	$this->tableindex = wub_prefix . "dataindex";
	   	$this->tablevalue = wub_prefix . "datavalues";
	}
	
	function FetchID($uid, $cat = null)
	{
		global $wpdb;
		if (!$cat) $cat = $this->cat;

		$query = "SELECT id FROM $this->tableindex WHERE uid=$uid AND gid={$this->gid} AND cat='{$cat}'";
		$id = $wpdb->get_var($query);
		if ($id)
			return $id;
		return null;
	}
	function FetchCategoryIDsLike($uid, $cat)
	{
		global $wpdb;

		$tablekey = wub_prefix . 'dataindex';
		$query = "SELECT id, cat FROM $tablekey WHERE uid = '$this->uid' AND gid = '$this->gid' AND cat LIKE '%$cat%' ORDER BY id";
		
		$ids = $wpdb->get_results($query);
		if ($ids)
			return $ids;
		return null;
	}
	function FetchCategoryIDs($uid, $gid)
	{
		global $wpdb;

		$query = "SELECT id, cat FROM $this->tableindex WHERE uid = $this->uid AND gid = $gid ORDER BY id";
		
		$ids = $wpdb->get_results($query);
		if ($ids)
			return $ids;
		return null;
	}
	function FetchOrCreateID($uid, $cat)
	{
		if (!$cat) $cat = $this->cat;
		$id = FetchId($uid, $cat);
		if ($id) return $id;
		
		$wpdb->insert($tablekey, array('uid' => $uid, 'gid' => $this->gid, 'cat' => $cat), array('%d','%d','%s',));
		return $wpdb->insert_id;
	}

	
	public function ReturnResults($print_gid = false)
	{
		if (null === $this->data)
		{
			SendToUnity( PrintError("Empty response. No data found") );
			return;
		}
			
		$result = SendField("success","true");
		$old_id = -1; 
		foreach($this->data as $category)
		{
			if ($category->gid != $old_id && $print_gid)
			{
				$gid = $category->gid;
				if ($gid == 0)
					$gid = "Global";
				$result .= SendNode("_GAME_", "gid=$gid");
				$old_id = $category->gid;
			}
			$result .= $category->ToCML();
		}
		SendToUnity($result);
	}

	public function fetch_field($fid)
	{
		global $wpdb;
		
		$id = $this->FetchID($this->uid);
		if (!$id) return;
		
		$query = "SELECT fval FROM $this->tablevalue WHERE id = $id AND fid = '$fid'";
		$result = $wpdb->get_var($query);
		if (null != $result)
		{
			$temp = new dDataContainer($this->gid, $this->cat);
			$temp->AddField($fid, $result);
			$this->data[] = $temp;
		} else
		{
			$temp = new dDataContainer($this->gid, $this->cat);
			$temp->AddField("ERROR with field {$fid}", "found nothing under id:{$id}");
			$this->data[] = $temp;			
		}
	}

	public function fetch_cat_like($cat = "")
	{
		if ($cat == "")
			$cat = $this->cat;
		$cat = stripslashes($cat);

		global $wpdb;

		$ids = $this->FetchCategoryIDsLike($this->uid, $cat);
		if (!$ids) return;

		foreach($ids as $row)
		{
			$category = $row->cat;
			$query = "SELECT fid, fval FROM $this->tablevalue WHERE id = '$row->id'";
			$rows = $wpdb->get_results($query);
			if ($rows)
			{
				$last_cat = time();
				$temp = new dDataContainer($this->gid, $category);

				foreach ($rows as $row )
					$temp->AddField($data->fid, $data->fval);
				
				$this->data[] = $temp;
			}
		}
	}

	public function fetch_cat($cat = "")
	{
		if ($cat == "")
			$cat = $this->cat;

		global $wpdb;
		$id = $this->FetchId($this->uid, $cat);
		if (!$id) return;
		
		$query = "SELECT fid, fval FROM $this->tablevalue WHERE id = $id;";
	
		$result = $wpdb->get_results($query);
		if (null != $result)
		{
			$temp = new dDataContainer($this->gid, $cat);
			
			foreach ( $result as $data )
				$temp->AddField($data->fid, $data->fval);
				
			$this->data[] = $temp;
		}
	}
	
	public function fetch_game($gid = -1)
	{
		if ($gid == -1)
			$gid = $this->gid;

		global $wpdb;
		$cats = $this->FetchCategoryIDs($this->uid, $gid);
		if (!$cats) return;
		
		foreach($cats as $key_row)
		{
			$query = "SELECT fid, fval FROM $this->tablevalue WHERE id = $key_row->id;";

			$result = $wpdb->get_results($query);
			if ($result)
			{			
				$temp = new dDataContainer($gid, $key_row->cat);

				foreach ($result as $data )
					$temp->AddField($data->fid, $data->fval);		
				
				$this->data[] = $temp;
			}
		}
	}
	
	public function fetch_all_user_data()
	{
		global $wpdb;
		$games = $wpdb->get_results("SELECT DISTINCT gid FROM $this->tableindex WHERE uid = '$this->uid'", ARRAY_N);
		if ($games)
		{
			foreach($games as $game)
				$this->fetch_game($game[0]);
		}
	}
	
	public function delete_image($key) 
	{
		$this->fetch_field($key);
		if (count($this->data) == 0 || count($this->data[0]->fields) == 0 || !isset($this->data[0]->fields[$key]))
			return -1;

		$url = $this->data[0]->fields[$key];
		$images = new WubImages($this->uid);
		$result = $images->DeleteImage($url);
		if ($result !== TRUE)
			return -2;		

		$this->remove_field($key);
		return 0;
	}

	
	public function remove_field($fid)
	{
		global $wpdb;
		$id = $this->FetchID($this->uid);
		if (!$id) return;
		
		
		if (false === $wpdb->delete( $this->tablevalue, array( 'id' => $id, 'fid' => $fid ) ))
			SendToUnity( PrintError("Field could not be deleted") );
		else
		{
			$query = "SELECT COUNT(*) IN {$this->tablevalue} WHERE id=$id;";
			$entry_count = $wpdb->get_var($query);
			if (!$entry_count || $entry_count == 0)
				$wpdb->delete($this->tableindex, array('id'=>$id));
			
			SendToUnity( SendField("success", "true") ); 
		}
	}
	
	public function remove_cat($cat = "")
	{
		if ($cat == "")
			$cat = $this->cat;

		global $wpdb;
		$id = $this->FetchID($this->uid, $cat);
		if (!$id) return;
		
		if (false === $wpdb->delete( $this->tablevalue, array( 'id' => $id) ))
			SendToUnity( PrintError("Category could not be deleted") );
		else
		{
			$wpdb->delete($this->tableindex, array('id'=>$id));
			SendToUnity( SendField("success", "true") ); 
		}
	}
	
	public function remove_game($gid = -1)
	{
		if ($gid == -1)
			$gid = $this->gid;
			
		global $wpdb;
		$cats = $this->FetchCategoryIDs($this->uid, $gid);
		if (!$cats) return;

		foreach($cats as $cat)
		{
			$wpdb->delete( $this->tablevalue, array( 'id' => $cat->id ) );
			$wpdb->delete( $this->tableindex, array( 'id' => $cat->id ) );
		}
		SendToUnity( SendField("success","true") ); 
	}
	
	public function fetch_global_info()
	{
		$this->fetch_game(0);
	}
		
}
