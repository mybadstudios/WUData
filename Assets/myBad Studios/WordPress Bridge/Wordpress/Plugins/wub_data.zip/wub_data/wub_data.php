<?php
/*
Plugin Name: WordPress For Unity Bridge - Data
Plugin URI: https://mybadstudios.com/
Description: Store and retrieve any/all of your Unity game's data into your WordPress database
Version: 1
Network: true
Author: myBad Studios
Author URI: https://mybadstudios.com
*/

function activate_wudata()
{
	include_once(dirname(__FILE__) . "/../wub_login/functions.php");
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

	$data_table_wuss=	"CREATE TABLE IF NOT EXISTS "
						. wub_prefix
						."data (
						  uid integer unsigned NOT NULL DEFAULT 0,
						  gid integer UNSIGNED NOT NULL DEFAULT 0,
						  cat varchar(32) NOT NULL DEFAULT '',
						  fid varchar(128) NOT NULL DEFAULT '',
						  fval text NOT NULL DEFAULT '',
						  PRIMARY KEY  (uid,gid,cat,fid)
						);";
	
	$data_table_key	=	"CREATE TABLE IF NOT EXISTS "
						. wub_prefix
						."dataindex (
						  id integer unsigned AUTO_INCREMENT ,
						  uid integer unsigned NOT NULL DEFAULT 0,
						  gid integer UNSIGNED NOT NULL DEFAULT 0,
						  cat varchar(32) NOT NULL DEFAULT '',
						  PRIMARY KEY  (id)
						);";
	$data_table_val	=	"CREATE TABLE IF NOT EXISTS "
						. wub_prefix
						."datavalues (
						  id integer unsigned NOT NULL DEFAULT 0,
						  fid varchar(128) NOT NULL DEFAULT '',
						  fval text NOT NULL DEFAULT '',
						  PRIMARY KEY  (id, fid),
						  FOREIGN KEY (id) REFERENCES ".wub_prefix."dataindex (id)
						);";
	//dbDelta($data_table_wuss);
	dbDelta($data_table_key);
	dbDelta($data_table_val);			
}

//move data from old table structure to new tables then delete old table
function moveWUSSDataToWUBTables($delete = true)
{
	global $wpdb;
	$successful = true;	
	$starting_index = 0;
	
	while(true) 
	{
		$ROWS = $wpdb->get_results("SELECT * FROM {$wub_prefix}data WHERE ID > {$starting_index} LIMIT 100");
		if (!$ROWS) break;
		foreach($ROWS as $row)
		{
			$starting_index = $row->ID;
			$uid = $row->uid;
			$gid = $row->gid;
			$cat = $row->cat;
			$fid = $row->fid;
			$fval = $row->fval;

			$id = $wpdb->get_var("SELECT id FROM {$wub_prefix}dataindex WHERE uid={$uid} AND gid={$gid} AND cat ={$cat}");
			if(!$id)
			{
				if (!$wpdb->insert( 
						"{$wub_prefix}dataindex", 
						array( 
							'uid' => $uid, 
							'gid' => $gid, 
							'cat' => $cat 
						), 
						array( 
							'%d', 
							'%d', 
							'%s', 
						) )
					)
				{
					$successful = false;
					echo "Unable to create key uid:{$uid} gid:{$gid} cat:{$cat}";
					continue;
				}
				else
				{
					$id = $wpdb->insert_id;
				}
			}
			
			if (!$wpdb->replace( 
					"{$wub_prefix}datavalues", 
					array( 
						'id' => $id,
						'fid' => $fid, 
						'fval' => $fval, 
					), 
					array( 
						'%d', 
						'%d', 
						'%s', 
					) )
				)
			{
				$successful = false;
				echo "Could not create entry id:{$id} key:{$fid} value:{$fval}";				
			}
		}
	}
	
	if ($delete){
		$table_name = wub_prefix . 'data';
		$sql = "DROP TABLE IF EXISTS $table_name";
		//$wpdb->query($sql);
	}
}

function deactivate_wudata(){
	//currently don't have anything to do here...
}

function uninstall_wudata() {
	include_once(dirname(__FILE__) . "/../wub_login/functions.php");
   	//delete the table created by this kit...
	global $wpdb;
    $query0 = "
	DROP TABLE IF EXISTS ". wub_prefix ."data;
	DROP TABLE IF EXISTS ". wub_prefix ."dataindex;
	DROP TABLE IF EXISTS ". wub_prefix ."datavalues;
	";

	//uncomment this if you want to destroy your tables and data upon uninstall
	//	$wpdb->query($query0);
}

register_activation_hook( __FILE__,	'activate_wudata'	);
register_deactivation_hook( __FILE__,	'deactivate_wudata'	);
register_uninstall_hook( __FILE__,	'uninstall_wudata'	);

include_once(dirname(__FILE__) ."/settings.php");
