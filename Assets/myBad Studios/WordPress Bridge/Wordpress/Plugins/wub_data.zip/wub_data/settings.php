<?php		
    include_once(dirname(__FILE__) . "/../wub_login/functions.php");
	include_once("Settings/wub_data.php");

    add_filter("wub_section_heading", "wub_add_data_menu",13,2);
    add_filter("wub_section_content", "wub_show_data_section", 15, 2);
    
    function wub_add_data_menu($value)
    {
        $menu_button = new WubMenuItem('Data');
        return $value . $menu_button->GenerateMenuButton();
    }
    
    function wub_show_data_section($content, $test)
    {
        return (MENUTAB == 	DATA_CONSTANT) ? show_wub_data_content() : $content;
    }
